export type CreateMajorDto = {
    name: string;
    code: string;
    description?: string;
};
  